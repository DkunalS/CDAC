
str1 = """this is acts pune and we are learning python
 in artificial intelligence course in acts pune it is 
 professional course which exactly meet the industry demand"""
print(sorted(set(str1.split())))

