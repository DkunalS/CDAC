from sqlalchemy import create_engine, MetaData , Column, Integer, String, Sequence
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import inspect

engine = create_engine("sqlite:///students_data.db")
Base = declarative_base()

# creating the table using sqlalchemy
class Student_Details(Base):
    __tablename__ = "student_details"
    stud_id = Column(Integer, Sequence("student_id"), primary_key = True,)
    student_name = Column(String(50))
    subject_name = Column(String(50))
    marks = Column(Integer)

metadata = MetaData()
metadata.reflect(bind = engine)
Base.metadata.create_all(engine)
students = metadata.tables["student_details"]

inspector = inspect(engine)
columns = inspector.get_columns("student_details")

for column in columns:
    print(column)

Session = sessionmaker(bind = engine)
session = Session()
# data to be inserted into the table
students_data = [
    Student_Details(student_name = "Omkar", subject_name = "AI", marks = 75),
    Student_Details(student_name = "Kunal", subject_name = "ML", marks = 85),
    Student_Details(student_name = "Vishal", subject_name = "NLP", marks = 79),
    Student_Details(student_name = "Ajay", subject_name = "aptitude", marks = 86),
]

# inserting the record into the data
session.add_all(students_data)
session.commit()

all_students = session.query(Student_Details).all()

# retrieving all the data
for student in all_students:
    print(f"Student Id: {student.stud_id}, Student Name: {student.student_name}, Subject Name: {student.subject_name}, Marks: {student.marks}")

# updating the marks
    student_update = session.query(Student_Details).filter_by(stud_id=2).first()
    student_update.marks = 86

# Final Details of all the student
for student in all_students:
     print(f"Student Id: {student.stud_id}, Student Name: {student.student_name}, Subject Name: {student.subject_name}, Marks: {student.marks}")