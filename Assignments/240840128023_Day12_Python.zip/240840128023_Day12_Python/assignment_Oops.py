#Task 1 - creating the base class
class MusicalInstrument:
    def __init__(self, name, type):
        self.__name = name  # Encapsulated attribute
        self.__type = type  # Encapsulated attribute
        self.__is_tuned = False  # Encapsulated attribute

    def play(self):
        print(f"Playing the {self.__name}...")

    def tune(self):
        self.__is_tuned = True
        print(f"{self.__name} is now tuned.")

    def check_tuning(self):
        if self.__is_tuned:
            print(f"{self.__name} is tuned.")
        else:
            print(f"{self.__name} is not tuned.")

    # Getters and setters for encapsulated attributes
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, value):
        self.__type = value

# Task-2 Implementing Inheritance

class Guitar(MusicalInstrument):
    def __init__(self, name, type, number_of_strings):
        super().__init__(name, type)
        self.__number_of_strings = number_of_strings

    def play(self):
        print(f"{self.name} is strumming.")

    # Getter and setter for number_of_strings
    @property
    def number_of_strings(self):
        return self.__number_of_strings

    @number_of_strings.setter
    def number_of_strings(self, value):
        self.__number_of_strings = value


class Piano(MusicalInstrument):
    def __init__(self, name, type, number_of_keys):
        super().__init__(name, type)
        self.__number_of_keys = number_of_keys

    def play(self):
        print(f"{self.name} is playing.")

    # Getter and setter for number_of_keys
    @property
    def number_of_keys(self):
        return self.__number_of_keys

    @number_of_keys.setter
    def number_of_keys(self, value):
        self.__number_of_keys = value


class Drum(MusicalInstrument):
    def __init__(self, name, type, drum_size):
        super().__init__(name, type)
        self.__drum_size = drum_size

    def play(self):
        print(f"{self.name} is being beaten.")

    # Getter and setter for drum_size
    @property
    def drum_size(self):
        return self.__drum_size

    @drum_size.setter
    def drum_size(self, value):
        self.__drum_size = value

# Task- 3  Implementing the polymorphism
def test_instruments(instruments):
    for instrument in instruments:
        instrument.play()
        instrument.tune()
        instrument.check_tuning()
        print()  # Add a blank line between instruments


instruments = [
    Guitar("Fender", "String", 6),
    Piano("Yamaha", "Percussion", 88),
    Drum("Roland", "Percussion", "Medium")
]

test_instruments(instruments)

guitar = Guitar("Fender", "String", 6)
piano = Piano("Yamaha", "Percussion", 88)
drum = Drum("Roland", "Percussion", "Medium")

guitar.tune()
piano.tune()
drum.tune()

instruments = [guitar, piano, drum]
test_instruments(instruments)

try:
    print(guitar.__name)
except AttributeError:
    print("Error: cannot access private attribute '__name' directly")

try:
    guitar.__name = "New Name"
except AttributeError:
    print("Error: cannot modify private attribute '__name' directly")

print(guitar.name)
guitar.name = "New Name"
print(guitar.name)