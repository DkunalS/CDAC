import sqlite3

connection = sqlite3.connect("studentsDatabase.db")
connection.execute("PRAGMA foreign_keys = 1")
cursor = connection.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS Subjects(
Subject_id INTEGER PRIMARY KEY,
Subject_Name TEXT NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS Students(
Student_id INTEGER PRIMARY KEY,
Student_Name TEXT NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS Student_Details(
Stud_Id INTEGER,
Subject_Id INTEGER,
Marks INTEGER NOT NULL,
FOREIGN KEY (Stud_Id) REFERENCES Students (Student_id),
FOREIGN KEY (Subject_Id) REFERENCES Subjects (Subject_id)
)
""")

subject_names = [("Python",), ("Data Analytics",), ("AI",), ("ML",)]
student_names = [("Kunal",), ("Dhruv",), ("Ashutosh",), ("Ajay",), ("Vishal",), ("chetan",),("priyanshu",)]
student_details = [(1,2,80),(2,1,81),(3,3,75),(4,3,91),(5,1,85),(6,2,86),(7,4,79)]

cursor.executemany("INSERT INTO Subjects (Subject_Name) VALUES (?)", subject_names)

cursor.executemany("INSERT INTO Students (Student_Name) VALUES (?)", student_names)

cursor.executemany("INSERT INTO Student_Details (Stud_Id, Subject_Id, Marks) VALUES (?,?,?)", student_details)

cursor.execute("""
SELECT Students.Student_Name, Subjects.Subject_Name, Student_Details.Marks FROM
Students JOIN Student_Details ON Students.Student_id = Student_Details.Stud_Id
JOIN Subjects ON Subjects.Subject_id = Student_Details.Subject_Id
""")
rows = cursor.fetchall()

for row in rows:
    print(f"Student Name: {row[0]}\t\t\tSubject: {row[1]}\t\t\tMarks: {row[2]}")

cursor.close()
connection.close()