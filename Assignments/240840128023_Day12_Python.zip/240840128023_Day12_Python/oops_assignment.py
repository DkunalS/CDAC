Task- 1
class MusicalInstrument:
    def __init__(self, name, type):
        self._name = name
        self._type = type
        self._is_tuned = False

    # Getter for name
    @property
    def name(self):
        return self._name

    # Setter for name
    @name.setter
    def name(self, name):
        self._name = name

    # Getter for type
    @property
    def type(self):
        return self._type

    # Setter for type
    @type.setter
    def type(self, type):
        self._type = type

    # Method to play the instrument
    def play(self):
        if self._is_tuned:
            print(f"The {self._name} is being played.")
        else:
            print(f"The {self._name} is not tuned.. tune it.")

    # Method to tune the instrument
    def tune(self):
        self._is_tuned = True
        print(f"The {self._name} is tuned.")

    # Method to check if the instrument is tuned
    def check_tuning(self):
        if self._is_tuned:
            print(f"The {self._name} is tuned.")
        else:
            print(f"The {self._name} is not tuned.")


# Task-2
# Child classes inheriting from MusicalInstrument

class Guitar(MusicalInstrument):
    def __init__(self, name, type, number_of_strings):
        super().__init__(name, type)
        self.number_of_strings = number_of_strings

    # Overriding play method
    def play(self):
        if self._is_tuned:
            print(f"The {self._name} is strumming with {self.number_of_strings} strings.")
        else:
            print(f"The {self._name} is not tuned. Please tune it before playing.")


class Piano(MusicalInstrument):
    def __init__(self, name, type, number_of_keys):
        super().__init__(name, type)
        self.number_of_keys = number_of_keys  # Additional attribute for Piano

    # Overriding play method
    def play(self):
        if self._is_tuned:
            print(f"The {self._name} is playing with {self.number_of_keys} keys.")
        else:
            print(f"The {self._name} is not tuned. Please tune it before playing.")


class Drum(MusicalInstrument):
    def __init__(self, name, type, drum_size):
        super().__init__(name, type)
        self.drum_size = drum_size  # Additional attribute for Drum

    # Overriding play method
    def play(self):
        if self._is_tuned:
            print(f"The {self.drum_size} {self._name} is being beaten.")
        else:
            print(f"The {self._name} is not tuned. Please tune it before playing.")

# Task- 3
# Function demonstrating polymorphism
def test_instruments(instruments):
    for instrument in instruments:
        instrument.check_tuning()  # Checking tuning status
        instrument.play()  # Playing the instrument

# Task- 4

# Creating instances of the instruments
guitar = Guitar("Guitar", "String", 6)
piano = Piano("Piano", "Percussion", 88)
drum = Drum("Drum", "Percussion", "Large")

# Tuning all instruments
guitar.tune()
piano.tune()
drum.tune()

# Testing the instruments using polymorphism
instruments = [guitar, piano, drum]
test_instruments(instruments)

# Demonstrating encapsulation: Attempting to access private attributes
try:
    print(guitar._name)  # Directly accessing the encapsulated _name attribute (not recommended)
except AttributeError as e:
    print("Error:", e)

# Correct way to access private attributes via getter method
print("Guitar name:", guitar.name)  # Using the getter method for name
guitar.name = "Electric Guitar"  # Using the setter method to modify the name
print("Updated Guitar name:", guitar.name)
